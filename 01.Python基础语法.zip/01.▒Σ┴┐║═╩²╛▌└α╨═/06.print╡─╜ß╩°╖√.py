# 语法：print('',end='')
print('hello',end='\n') # python print()默认自带end='\n'
print('python',end='\t')
print('hello',end=',')
print('python')