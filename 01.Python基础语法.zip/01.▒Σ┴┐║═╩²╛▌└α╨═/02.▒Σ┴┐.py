# 变量：存储数据时当前数据所在内存地址的名称
#   注：变量名自定义，满足标识符命名规则

"""
标识符命名规则（Python中定义各种变量时的规范）：
*由数字、字母、下划线组成
*不能由数字开头
*不能用内置关键字（if、while等）
*严格区分大小写
"""

"""
命名习惯：
*见名知意
*大驼峰：每个单词字母大写（如MyNameIs）
*小驼峰：第二个及以后单词首字母大写（如myNameIs）
*下划线（如ma_name_is）
"""


# 定义变量：存储数据szy
my_name = 'szy'  # 定义变量
print(my_name)  # 使用变量

# 定义变量：存储数据schzene
English_name = 'schzene'
print(English_name)

# 代码自上而下执行