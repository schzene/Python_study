# \n：换行
# \t：制表符，一个tab键（4个空格）的距离

print('hello')
print('python')
print('hello\npython')
print('\tthis is a test')