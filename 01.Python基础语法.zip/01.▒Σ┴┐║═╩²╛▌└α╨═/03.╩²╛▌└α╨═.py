# 数值
a=1  # int(整型或整数)
print(type(a))
b=1.1  # float(浮点型或小数)
print(type(b))

# bool(布尔型)
d=True
e=False
print(type(d))

# str(字符串)
c='hello!'
print(type(c))

# list(列表型)
f=[1,2,3]
print(type(f))

# tuple(元组型)
g=(1,2,3)
print(type(g))

# set(集合)
h={1,2,3}
print(type(h))

#dict(字典)
i={'自变量': 'x' , '因变量': 'y'}
print(type(i))