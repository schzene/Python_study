'''
1.出拳
    玩家：手动输入
    电脑：1.固定剪刀 2.随机
2.判断
    1.玩家赢
    2.电脑赢
    3.平局  
'''

p=int(input('请出拳（0代表石头，1代表剪刀，2代表布）：'))  
c=1
print('电脑出的是剪刀。')
if ((p==0)and(c==1))or((p==1)and(c==2))or((p==3)and(c==0)):
    print('恭喜，您赢了！')
elif ((c==0)and(p==1))or((c==1)and(p==2))or((c==3)and(p==0)):
    print('对不起，您输了！')
elif p==c:
    print('平局！')
else:
    print('错误！')    