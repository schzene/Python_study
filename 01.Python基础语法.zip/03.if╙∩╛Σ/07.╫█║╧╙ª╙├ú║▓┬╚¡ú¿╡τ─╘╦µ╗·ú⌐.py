'''
随机实现方法：
1.导入模块
import 模块名
2.使用random模块中的随机整数功能
random.randint(开始,结束)
'''

import random
flag = 1
while flag !=0:
    c=random.randint(0,2)
    p=int(input('请出拳（0代表石头，1代表剪刀，2代表布）：'))

    if c==0 :
        print('电脑出的是石头。')
    elif c==1 :
        print('电脑出的是剪刀。')
    else :
        print('电脑出的是布。')

    if ((p==0)and(c==1))or((p==1)and(c==2))or((p==2)and(c==0)) :
        print('恭喜，您赢了！')    
    elif p==c :
        print('平局！')    
    elif p>2 :
        print('错误！')
    else:
        print('对不起，您输了！')
    flag=int(input('继续吗？（输入1继续，输入0退出）：'))

input('按Enter键退出')