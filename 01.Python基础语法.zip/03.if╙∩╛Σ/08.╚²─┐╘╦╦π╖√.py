'''
语法：
条件成立的代码 if 条件 else 条件不成立的代码
'''

a=1
b=2
c= a-b if a>b else b-a
print(c)