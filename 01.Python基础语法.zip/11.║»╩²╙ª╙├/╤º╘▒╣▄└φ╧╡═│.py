# 1.1 系统简介
"""
进入系统显示系统功能界面，功能如下
1、添加学员
2、删除学员
3、修改学员信息
4、查询学员信息
5、显示所有学员信息
6、退出系统
"""
# 系统共6个功能，用户根据自己需求选择

# 1.2 步骤简介
"""
1、显示功能界面
2、用户输入功能序号
3、根据用户输入的序号执行不同的函数
    3.1、定义函数
    3.2、调用函数
"""

# 1.3 功能实现

# 存储所有学员信息是一个全局变量，数据类型为列表
# 列表里面嵌套字典
info=[]

def info_print():
    """显示界面"""
    print("-"*20)
    print("请选择功能")
    print("1：添加学员")
    print("2：删除学员")
    print("3：修改学员信息")
    print("4：查询学员信息")
    print("5：显示所有学员信息")
    print("6：退出系统")
    print("-"*20)

def add_info():
    """添加学员函数"""
    new_id=input("请输入学号：")
    new_name=input("请输入姓名：")  # 接收用户输入学员信息
    global info
    for i in info:  # 检测用户输入的姓名是否存在
        if new_name==i["name"]:
            print("该学员已存在！")
            return  # 退出当前函数
    info_dict={}
    info_dict["id"]=new_id
    info_dict["name"]=new_name
    info.append(info_dict)
    print("该学员已添加")

def delete_info():
    """删除学员数据"""
    del_name=input("请输入要删除的学员姓名")
    global info
    for i in info:
        if del_name==i["name"]:
            info.remove(i)
            print("该学员已删除")
            break
    else:
        print("该学员不存在！")

def modify_info():
    """修改学员信息函数"""
    modify_name=input("请输入要修改的学员姓名")
    global info
    for i in info:
        if modify_name==i["name"]:
            i["id"]=input("请输入新的学号")
            break
    else:
        print("该学员不存在")

def search_info():
    """查询学员信息函数"""
    search_name=input("请输入要查找的学员姓名")
    global info
    for i in info:
        if search_name==i["name"]:
            print("查找的学员信息如下：")
            print(f"学号：{i['id']},姓名：{i['name']}")
            break
    else:
        print("该学员不存在")

def print_all():
    """显示所有学员信息函数"""
    print("学号\t姓名")
    global info
    for i in info:
        print(f"{i['id']}\t{i['name']}")

while True:
# 显示功能界面
    info_print() 

# 用户输入功能序号
    user_num=int(input("输入功能序号："))

# 根据用户输入的序号执行不同的函数
    print()
    if user_num==1:
        add_info()
    elif user_num==2:
        delete_info()
    elif user_num==3:
        modify_info()
    elif user_num==4:
        search_info()
    elif user_num==5:
        print_all()
    elif user_num==6:
        exit_flag=input("确定退出？（Y/n）:")
        if exit_flag=="y" or exit_flag=="Y":
            break
    else:
        print("输入错误！")
    print()