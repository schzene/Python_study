mlist=[['a','b','c'],[1,2,3]]
print(mlist[1])
print(mlist[1][2])
