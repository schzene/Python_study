# 遍历：依次访问列表中的各个数据

list0=['a','b','c','b']

# while
i=0
while i<len(list0) :
    print(list0[i])
    i+=1

# for
for i in list0 :
    print(i)