list0=['a','b','c','b']

# 列表的下标
print(list0[0])
print(list0[1])
print(list0[2])

# 列表的函数：index(),count(),len()
# 注：1.index(),count()性质与在字符串中的一样
#     2.len()：访问列表长度，即列表中数据个数
print(list0.index('c'))
print(list0.count('b'))
print(len(list0))
       