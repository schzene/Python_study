t0=('a','b','c','b')
print(t0[0])  # 下标
print(t0.index('b',2,4))  # index()
print(t0.count('b'))  # count()
print(len(t0))