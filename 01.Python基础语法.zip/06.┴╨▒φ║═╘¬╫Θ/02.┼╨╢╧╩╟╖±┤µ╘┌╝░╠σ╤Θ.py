list0=['a','b','c','b']
# 判断是否存在：in与not in
print('a' in list0)
print('d' in list0)

print('a' not in list0)
print('d' not in list0)

# 体验
list1=['a','b','c','d','e','f','g']
a=input('请输入：')
if a in list1 :
    print(f'你输入的是{a},已存在')
else :
    print(f'你输入的是{a},不存在')