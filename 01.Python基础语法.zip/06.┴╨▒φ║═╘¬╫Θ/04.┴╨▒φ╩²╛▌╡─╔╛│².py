list0=['a','b','c','b']

'''
1.del
注意：del默认删除整个列表
'''
# del list0
# del list0[0]
print(list0) 
'''
2.pop()
语法：列表.pop(数据下标)
注意：1.pop默认删除列表最后一个数据
     2.pop在删除一个数据后会返回这个被删除的数据
'''
# list0.pop(0)
# list0.pop()
print(list0)
'''
3.remove()
语法：列表.remove(数据)
注意：remove移除列表的第一个匹配项
'''
# list0.remove('b')
print(list0)
'''
4.clear()
注意：clear清空整个列表，不删除列表
'''
# list0.clear()
print(list0)