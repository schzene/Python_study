list0=['a','b','c','b']

copied_list=list0.copy()
print(copied_list)
print(list0)