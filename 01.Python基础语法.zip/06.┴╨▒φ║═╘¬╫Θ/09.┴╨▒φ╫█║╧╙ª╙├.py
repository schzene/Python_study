# 随机分配办公室
# 要求八个人随机分配到三个办公室

# 1.准备数据
teachers=['t0','t1','t2','t3','t4','t5','t6','t7']
offices=[[],[],[],]

# 2.分配老师到办公室
import random

for teacher in teachers :
    n=random.randint(0,2)
    offices[n].append(teacher)

# 3.验证
i=1
for office in offices :
    print(f'办公室{i}有{len(office)}位老师,分别是：')
    i+=1
    for name in office :
        print(name)
