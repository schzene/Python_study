list0=['a','b','c','b']

# 修改指定下标的数据
# list0[0]='z'
print(list0)

# 逆序
list0.reverse()
print(list0)

# 排序（升序或降序）
list1=[4,3,56,5,7,6]
# 语法：列表.sort(key=None,reverse=False)
# 注： 1.key表示指定字典(默认为None)
#     2.reverse=True表示降序，=False表示升序（默认）
# list1.sort()
list1.sort(key=None,reverse=True)
print(list1)