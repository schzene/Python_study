list0=['a','b','c','d']

# 列表结尾加数据
'''
1.append()
   注：如果append追加的数据是一个序列，追加整个序列到列表结尾
'''
# list0.append('ef')
# list0.append(['ef','gh'])
print(list0)

'''
2.extend()
   注：如果append追加的数据是一个序列，追加序列数据到列表结尾
'''
# list0.extend('ef')
# list0.extend(['ef','gh'])
print(list0)


# 指定位置加数据
'''
insert()
'''
list0.insert(1,'ef')
print(list0)


# 注意：列表是可变类型