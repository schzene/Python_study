# 一个元组存储多个数据，元组内数据不可修改。
t0=('a','b','c','b')  # 多个数据
t1=(1,)  # 单个数据
t2=(2)
print(type(t0))
print(type(t1))
print(type(t2))