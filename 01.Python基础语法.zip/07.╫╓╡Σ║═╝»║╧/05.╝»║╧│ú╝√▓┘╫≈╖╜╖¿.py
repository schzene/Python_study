# 1.增加数据

# add()：增加单个数据
s1_1={10,20}
s1_1.add(100)
s1_1.add(10)
print(s1_1)
print()

# update()：增加数据序列
s1_2={10,20}
# s1_2.update(100)  # 报错
s1_2.update([100,200])
s1_2.update('abc')
print()


# 2.删除数据

# remove()：数据不存在就报错
s2_1={10,20}
s2_1.remove(10)
print(s2_1)
# s2_1.remove(30)  # 报错
# print(s2_1)

# discard()：数据不存在不报错
s2_2={10,20}
s2_2.discard(10)
print(s2_2)
s2_2.discard(30)
print(s2_2)

# pop()：随机删除
s2_3={10,20,30,40,50}
del_num=s2_3.pop()
print(del_num)
print(s2_3)


# 3.查找数据

# in：判断数据在集合序列
#  not in：判断数据不在集合序列
s3_1={10,20,30,40,50}
print(10 in s3_1)
print(20 not in s3_1)
