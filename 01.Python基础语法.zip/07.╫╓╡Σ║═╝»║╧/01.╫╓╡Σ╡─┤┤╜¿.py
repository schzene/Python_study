'''
字典的特点：
1.符号为大括号
2.数据为键值对形式出现
3.各个键值对之间用逗号隔开
'''

# 有数据的字典
dict1={'name':'Tom','age':20,'sex':'male'}

# 空字典
dict2={}
dict3=dict() 

print(dict1)
print(type(dict1))