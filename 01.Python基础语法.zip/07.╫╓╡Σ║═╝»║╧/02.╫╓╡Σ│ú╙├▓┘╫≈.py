# 1.增
dict1={'name':'Tom','age':20,'sex':'male'}
dict1['name']='Bob'
dict1['id']=110
print(dict1)
print()
'''
注意：
1.如果key存在则修改key的值，反之则新增此键值对
2.字典为可变类型
'''


# 2.删
# del()
dict2={'name':'Tom','age':20,'sex':'male'}
del dict2['name']
# del(dict2)  # 删除整个字典
print(dict2)
print()
# clear()
dict1.clear()
print(dict2)
print()


# 3.改
# 写法：字典序列[key]=值
dict3={'name':'Tom','age':20,'sex':'male'}
dict3['name']='Mike'
print(dict3)
print()


# 4.查找

# key值查找
dict4={'name':'Tom','age':20,'sex':'male'}
print(dict4['name'])
print()
# get()
dict4_1={'name':'Tom','age':20,'sex':'male'}
print(dict4_1.get('name'))  # Tom
print(dict4_1.get('id',110))  # 110 # 如果查找的key不存在返回第二个参数（默认值）
print(dict4_1.get('grade'))  # None # 如果省略第二个参数，则返回None
print()
# keys() # 查找字典中所有的key，返回可迭代对象
dict4_2={'name':'Tom','age':20,'sex':'male'}
print(dict4_2.keys())  # 输出的对象是可遍历的
print()
# values()：查找字典中所有的value，返回可迭代对象
dict4_3={'name':'Tom','age':20,'sex':'male'}
print(dict4_3.values())  # 输出的对象是可遍历的
print()
# items()：查找字典中所有的键值对，返回可迭代对象，其中的数据是元组，元组数据1是字典的key，元组数据2是字典key对应的值
dict4_4={'name':'Tom','age':20,'sex':'male'}
print(dict1.items())  # 输出的对象是可遍历的
print()