# 共用全局变量

glo_num1=0

def test1():
    global glo_num1
    glo_num1=100

def test2():
    print(glo_num1)

test2()
test1()
test2()


# 返回值作为参数传递

def test1():
    return 0

def test2(num):
    print(num)

test2(test1())