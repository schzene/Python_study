# 在Python中，值是靠引用来传递的
# 可以用id()来判断是否为同一个值的引用
a=1
b=a
print(b)

print(id(a))
print(id(b))

a=2
print(b)  # int类型为不可变类型
print(id(a))
print(id(b))  # 修改了a的数据，再次开辟内存

aa=[10,20]
bb=aa

print(id(aa))
print(id(bb))

aa.append(30)
print(bb)  # 列表类型为可变类型
print(id(aa))
print(id(bb))


# 引用当做实参
def test1(a):
    print("-"*20)
    print(a)
    print(id(a))

    a+=a

    print(a)
    print(id(a))
    print("-"*20)

# int：计算前后id值不同
b=100
test1(b)

# 列表：计算前后id值相同
c=[11,22]
test1(c)

"""
可变类型：
        列表
        字典
        集合
不可变类型：
        整型
        浮点型
        字符串
        元组
"""