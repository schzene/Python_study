def buy():
    return "nothing"
    print("ok")  # return后面的语句不执行，执行到return语句后退出当前函数
goods=buy()
print(goods)

def add_num(a,b):
    return a+b
print(add_num(10,20))


# 多个返回值
def return_num1():
    return 1
    return 0  # return后面的语句不执行,即第一个return后的return不执行
print(return_num1())  # 1

def return_num2():
    return 1,2
result=return_num2()
print(result)

# return后面可以直接书写元组、列表、字典，返回多个值
def return_num3():
    # return(10,20)
    # return[100,200]
    return{"name":"Python","num":100}
all_result=return_num3()
print(all_result)