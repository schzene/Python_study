# help()函数：查看函数的说明文档

# 定义函数说明文档：
# def 函数名(参数):
#     """说明文档的位置"""
#     代码1
#     代码2
#     ...

def add_num(a,b):
    """求和函数"""
    return a+b
help(add_num)
