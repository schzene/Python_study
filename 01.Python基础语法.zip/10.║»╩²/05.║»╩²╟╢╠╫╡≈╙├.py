def testB():
    print("-----testB start-----")
    print("this is testB's code")
    print("-----testB end-------")
def testA():
    print("-----testA start-----")
    testB()  # 嵌套调用testB()  
    print("-----testA end-------")

testA()