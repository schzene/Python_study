# 元组拆包
def return_num():
    return 100,200
num1,num2=return_num()
print(num1)  # 100
print(num2)  # 200

# 字典拆包
dict1={"name":"Bob","age":18}
a,b=dict1
print(a)
print(b)