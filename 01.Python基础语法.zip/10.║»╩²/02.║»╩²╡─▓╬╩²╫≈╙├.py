def num():
    result=1+2
    return result
def add_num(a,b):  # a，b在这里作为形参
    result=a+b
    return result
a=add_num(10,20)  #10，20在这里作为实参
print(num())
print(a)


# 位置参数：调用函数时根据函数定义的参数位置来传递参数
def user_info1(name,age,gender):
    print(f"your name is {name}, age is {age}, gender is {gender}.")
user_info1("Bob",20,"male")
# 注意：传递和定义参数的顺序及个数必须一致


# 关键字参数：函数调用，通过“键=值”形式加以指定
# 优点：可以让函数更加清晰、容易使用，同时也清除了参数的顺序需求
def user_info2(name,age,gender):
    print(f"your name is {name}, age is {age}, gender is {gender}.")
user_info2("Alice",age=20,gender="female")
user_info2("Bob",gender="male",age=16)
# 注意：函数调用时，如果有位置参数，位置参数必须在关键字蚕食前，但关键字参数之间不存在先后顺序


# 缺省参数（默认参数）：用于定义函数，为参数提供默认值，调用函数时可不传该默认参数的值
def user_info3(name,age,gender="male"):
    print(f"your name is {name}, age is {age}, gender is {gender}.")
user_info3("Bob",20)
user_info3("Rose",18,"female")
# 注意:1.所有位置参数必须出现在默认参数前，包括函数定义和调用
#      2. 函数调用时，如果为缺省参数传值则修改默认参数值，否则使用这个默认值


# 不定长参数（可变参数）：用于不确定调用的时候会传递多少个参数（不传参亦可）的场景，
# 此时，用包裹（packing）位置参数，或者包裹关键字参数，来进行参数传递，会显得非常方便。
def user_info4_1(*args):
    print(args)
user_info4_1("Bob")
user_info4_1("Bob",18)  # 包裹位置传递
# 注意：传进的所有参数都会args变量收集，并根据传进参数的位置合并为一个元组，args是元组类型
def user_info4_2(**kwargs):
    print(kwargs)
user_info4_2(name="Bob",age=18,id=110)  # 包裹关键字传递
# 综上，无论是包裹位置传递还是包裹关键字传递，都是一个组包的过程
