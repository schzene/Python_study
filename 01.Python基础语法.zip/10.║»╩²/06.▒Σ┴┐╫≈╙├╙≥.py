# 变量作用域：变量生效的范围，主要分为局部变量和全局变量

# 局部变量：定义在函数体内部的变量，即只在函数体内部生效
# 作用：再函数体内部，临时保存数据，即当函数调用完成后，则销毁局部变量
def testA():
    a=100
    print(a)

testA()  # 100
# print(a)  # 报错：name 'a' is not defined

# 全局变量：在函数体内外都能生效的变量
b=100
def testC():
    print(b)

def testD():
    print(b)

def testE():
    b=200  # b只是局部变量
    print(b)

# 修改全局变量
def testF():
    global b  # 声明b为全局变量
    b=200

testC()
testD()
testE()
print(f'全局变量为{b}')
testF()
print(f'全局变量为{b}')