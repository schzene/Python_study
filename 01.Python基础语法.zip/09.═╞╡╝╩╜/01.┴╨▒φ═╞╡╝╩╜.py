# 列表推导式：用一个表达式创建一个有规律的列表或控制一个有规律的列表

# 创建0~9的列表：
"""
# while循环创建有规律列表
list1_1=[]  # 准备一个空列表
i=0
while i<10:
    list1_1.append(i)
    i+=1  # 书写循环，依次追加数字到空列表中
print(list1_1)

# for循环创建有规律列表
list1_2=[]
for i in range(10):
    list1_2.append(i)
print(list1_2)
"""
# 列表推导式实现
list1_3=[i for i in range(10)]
print(list1_3)


# 创建0~9的偶数列表：
"""
# 方法一：range()步长实现
list2_1=[i for i in range(0,10,2)]
print(list2_1)

# 方法二：for加if实现
list2_2=[]
for i in range(10):
    if i%2==0:
        list2_2.append(i)
print(list2_2)
"""
# 方法三：带if的列表推导式实现
list2_3=[i for i in range(10) if i%2==0]
print(list2_3)


# 创建列表[(1, 0), (1, 1), (1, 2), (2, 0), (2, 1), (2, 2)] 
# 多个for循环实现列表推导式
list3_1=[(i,j) for i in range(1,3) for j in range(3)]
print(list3_1)
"""
list3_2=[]
for i in range(1,3):
    for j in range(3):
        list3_2.append((i,j))
print(list3_2)
"""