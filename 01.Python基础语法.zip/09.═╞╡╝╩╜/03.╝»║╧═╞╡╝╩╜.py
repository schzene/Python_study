list1={1,1,2}
# 需求：创建一个集合，数据为列表的平方
set1={i**2 for i in list1}
print(set1)  # 注意集合有数据去重功能