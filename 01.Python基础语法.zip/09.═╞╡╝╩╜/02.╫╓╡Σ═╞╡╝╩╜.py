# 字典推导式：快速合并列表为字典或提取字典中目标数据

# 创建字典{1: 1, 2: 4, 3: 9, 4: 16}
dict1_1={i:i**2 for i in range(1,5)}
print(dict1_1)

# 合并列表为字典
list1=["name","num"]
list2=["Python",100]
dict1_2={list1[i]:list2[i] for i in range(len(list1))}
print(dict1_2)
# 如果两个列表数据个数相同，len统计任何一个列表的长度都可以
# 如果两个列表数据个数不同，len统计数据多的列表的长度会报错，len统计数据少的列表的长度不会报错

# 提取字典中的目标数据
# 需求： 提取数量大于等于200的字典数据
counts={"MBP":268,"HP":125,"DELL":201,"Lenovo":199,"acer":99}
count1={key:value for key,value in counts.items() if value>=200}
print(count1)
