"""
1.算术运算符：
    +：加、-：减、*：乘、/：除、//：整除、%：取余、**：指数（幂）、()：小括号
    优先级：()高于**高于*、/、//、%高于+、-
    例：9%4=1、9//4=2、(1+2)*3=9、2**4=2*2*2*2=16
"""

"""
2.赋值运算符（=）：将=右侧的结果赋值给左边的变量
    多变量赋值（a,b,c=1,2,3等价于a=1,b=2,c=3）
"""

"""
3.复合赋值运算符（+=、-=、*=、/=、//=、%=、**=）
"""
a=1
a+=2  # a=a+2
print(a)

b=3
c=4
b-=c  #b=b-c
print(b)

d=5
e=6
d*=e+7  # d=d*(e+7)
print(d)

"""
4.比较运算符
    ==（）a=3,b=3,a==b为True
    !=（）a=1,b=2,a==b为False,a!=b为True
    >（）a=1,b=2,a>b为True
    <（）a=1,b=2,a<b为True
    >=（）a=1（2）,b=2（2），a>=b为False（True）
    <=（）a=1（2）,b=2（2），a<=b为True（True）
"""

"""
5.逻辑运算符
    and（且）Ture and False = False （a and b）
    or（或）False or True = True （a or b）
    not（非）not True = False （not a）
    注：若a，b表达式有多项，用括号（(a+b)and(c+d)）
"""