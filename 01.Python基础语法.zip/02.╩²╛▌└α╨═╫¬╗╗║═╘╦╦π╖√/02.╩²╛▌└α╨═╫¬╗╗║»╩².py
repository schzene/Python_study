# 1.int() 将数据转换为整数型
float0=1.0
print(type(int(float0)))
print(int(float0))

# 2.float() 将数据转换为浮点数型
num0=0
str0='01'
print(type(float(num0)))
print(float(num0))
print(type(float(str0)))
print(float(str0))

# 3.str() 将数据转换为字符串型
num1=1
print(type(str(num1)))
print(str(num1))

# 4.tuple() 将序列转换为一个元组
list0=[1,2,3]
print(type(tuple(list0)))
print(tuple(list0))

# 5.list() 将序列转换为一个列表
tuple0=(1,2,3)
print(type(list(tuple0)))
print(list(tuple0))

# 6.eval() 用来计算在字符串中的有效Python表达式并返回一个对象
str1='1'
str2='1.1'
str3='(1,2,3)'
str4='[1,2,3]'
print(type(eval(str1)))
print(type(eval(str2)))
print(type(eval(str3)))
print(type(eval(str4)))


# 数据类型转换函数
#   函数                       说明
"""
   *int(x[,base])              将x转换为整数
   *float(x)                   将x转化为浮点数
   *str(x)                     将x转化为字符串
   *eval(str)                  用来计算在字符串中的有效Python表达式并返回一个对象
   *tuple(s)                   将序列s转换为一个元组
   *list(s)                    将序列s转换为一个列表
    complex(real[imag])        创建一个复数，real为实部，imag为虚部
    rerpr(x)                   将x转换为表达式字符串
    chr(x)                     将一个整数转换为一个Unicode字符
    ord(x)                     将一个字符转换为它的一个ASCII整数值
    hex(x)                     将一个整数转换为十六进制字符串
    oct(x)                     将一个整数转换为八进制字符串
    bin(x)                     将一个整数转换为二进制字符串
"""