# 语法：input("提示信息")
# 特点：
#   Python中，input接收用户输入后，一般存储到变量，方便使用
#   Python中，input会把接收到的数据当作字符串处理
UserName=input('输入用户名：') 
print(type(UserName))
print(f'{UserName},你好！')

# 数据类型转换步骤
'''
1.input
2.检测input数据类型
3.转换数据类型
4.检测是否成功
'''
num=input('输入数值：')
print(type(num))
print(type(int(num)))
