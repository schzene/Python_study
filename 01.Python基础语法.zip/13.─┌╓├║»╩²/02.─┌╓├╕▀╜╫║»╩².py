# map(fn,lst),将传入的fn作用到lst的每个元素，并将结果组成新的迭代器（Python3）返回
list1=[1,2,3,4,5]
def fn(x):
    return x**2
result=map(fn,list1)
print(result)
print(list(result))

# reduce(fn(x,y),lst),fn必须有两个参数。每次fn计算的结果继续和序列的下一个元素做累积计算
import functools  # reduce在functools中
list2=[1,2,3,4,5]
def fn2(a,b):
    return a+b
result=functools.reduce(fn2,list2)
print(result)

# filter(fn,lst),用于过滤序列，过滤掉不符合条件的元素，返回一个filter对象
list3=[1,2,3,4,5,6,7,8,9,10]
def fn3(x):
    return x%2==0
result=filter(fn3,list3)
print(result)
print(list(result))
