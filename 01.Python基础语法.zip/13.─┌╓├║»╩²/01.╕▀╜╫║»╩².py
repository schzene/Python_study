# 把函数作为参数传入，这样的函数称为高阶函数，高阶函数是函数式编程的体现
# 函数式编程就是指这种高度抽象的编程范式
def add_num(a,b):
    return abs(a)+abs(b)
print(add_num(-1.1,1.9))

def sum_num(a,b,f):
    return f(a)+f(b)
print(sum_num(-1.1,1.9,abs))
print(sum_num(1.1,1.3,round))