str1='hello'

'''
语法：字符串序列.函数(总字符长度,'填充字符')
1.ljust()：左对齐
2.rjust()：右对齐
3.center()：中间对齐
'''

print('\'',end='')
print(str1.ljust(9),end='')
print('\'')

print(str1.ljust(9,'.'))
print(str1.rjust(9,'.'))
print(str1.center(9,'.'))