# isalpha()：如果字符串中至少有一个字符并且都是字母则返回True，否则为False
str1='abcde'
str2='abcde12345'
print(str1.isalpha())
print(str2.isalpha())

print()

# isdigit()：如果字符串中只包含数字则返回True，否则为False
str3='12345'
str4='12345abcde'
print(str3.isdigit())
print(str4.isdigit())

print()

# isalnum()：如果字符串中至少有一个字符并且都是数字或字母则返回True，否则为False
str5='1234 '
print(str1.isalnum())
print(str2.isalnum())
print(str3.isalnum())
print(str4.isalnum())
print(str5.isalnum())

print()

# isspace()：如果字符串中只包含空白则返回True，否则为False
str6='1 2 3 4 5'
str7='         '
print(str6.isspace())
print(str7.isspace())