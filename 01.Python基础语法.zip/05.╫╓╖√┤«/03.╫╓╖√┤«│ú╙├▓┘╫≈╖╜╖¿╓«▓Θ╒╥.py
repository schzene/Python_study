# 一.字符串查找方法：查找子串在字符串中出现的位置或次数
# （1）位置
# find()语法：字符串序列.find('字串',开始位置下标,结束位置下标)
# index()语法：字符串序列.index('字串',开始位置下标,结束位置下标)
# （2）次数
# count()语法：字符串序列.count('字串',开始位置下标,结束位置下标)
# 子串：表示字符串中的部分字符

mystr='hello world and itcast and computer and Python'

# find
print(mystr.find('and'))
print(mystr.find('and',15,30))
print(mystr.find('ands'))  # 显示-1，表示不存在

# index
print(mystr.index('and'))
print(mystr.index('and',15,30))
# print(mystr.index('ands'))  # 报错，表示不存在

# count
print(mystr.count('and'))
print(mystr.count('and',15,30))
print(mystr.count('ands'))

# rfind和rindex与find和index功能相同，但查找方向为从右侧开始
print(mystr.rfind('and'))
print(mystr.rindex('and'))