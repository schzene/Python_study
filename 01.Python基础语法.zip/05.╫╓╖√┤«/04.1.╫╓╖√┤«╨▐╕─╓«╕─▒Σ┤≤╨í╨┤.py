mystr='hello world and itcast and computer and Python'

'''
1.capitalize()：将字符串第一个字符转换为大写
注：只将第一个字符转换为大写，其他的全为小写
2.title()：将字符串每个单词首字母转换成大写
3.lower()：将字符串中的大写转换为小写
4.upper()：将字符串中的小写转换为大写
'''

print(mystr.capitalize())
print(mystr.title())
print(mystr.lower())
print(mystr.upper())
