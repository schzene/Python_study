print('Hello world!')

b='''Hello
python!'''
print(b)

print(f"I'd like to say--{b}")

print("I'm python!")
print('I\'m ptthon!')
