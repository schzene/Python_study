mystr='   hello world and itcast and computer and Python   '

'''
1.lstrip()：删除左侧空白字符
2.rstrip()：删除右侧空白字符
3.strip()：删除两侧空白字符
'''

print('\'',end='')
print(mystr,end='')
print('\'')

print('\'',end='')
print(mystr.lstrip(),end='')
print('\'')

print('\'',end='')
print(mystr.rstrip(),end='')
print('\'')

print('\'',end='')
print(mystr.strip(),end='')
print('\'')
