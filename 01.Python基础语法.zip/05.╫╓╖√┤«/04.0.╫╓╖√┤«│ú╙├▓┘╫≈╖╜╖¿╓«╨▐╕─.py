mystr='hello world and itcast and computer and Python'



'''
1.replace()
作用：替换
语法：字符串序列.replace('旧子串','新子串',替换次数)
注意：replace未修改原来字符串，修改的是返回值
'''
# 字符串是不可变类型
# 数据分为可变类型和不可变类型

print(mystr.replace('and','or'))
print(mystr.replace('and','or',2))
print(mystr.replace('and','or',10))
# 若替换次数超过子串出现次数，则全部替换


'''
2.split()
作用：按照指定字符分割字符串，返回一个列表
语法：字符串序列,split('分割字符',n)
注意：1.n表示分割字符出现次数，将来返回数据个数为n+1
     2.分割字符会丢失
'''

print(mystr.split('and'))
print(mystr.split('and',2))
print(mystr.split(' '))
print(mystr.split(' ',2))


'''
3.join()
作用：合并列表里的字符串为大字符串
语法：'字符或子串'.join(多字符串组成的序列)
'''

mylist=['a','b','c','d']
print('...'.join(mylist))
