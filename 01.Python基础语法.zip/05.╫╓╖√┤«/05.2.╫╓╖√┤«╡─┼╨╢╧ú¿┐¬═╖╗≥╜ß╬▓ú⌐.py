mystr='hello world and itcast and computer and Python'

'''
1.startswith()
作用：检查字符串是否以指定子串开头
语法：字符串序列.startswith('子串',开始位置下标,结束位置下标)
'''
print(mystr.startswith('he'))
print(mystr.startswith('hello'))
print(mystr.startswith('hello world'))
print(mystr.startswith('world'))
print(mystr.startswith('world',6,30))

print()

'''
2.endswith()
作用：检查字符串是否以指定子串结尾
语法：字符串序列.endswith('子串',开始位置下标,结束位置下标)
'''
print(mystr.endswith('Python'))
print(mystr.endswith('on'))
print(mystr.endswith('Pythons'))
