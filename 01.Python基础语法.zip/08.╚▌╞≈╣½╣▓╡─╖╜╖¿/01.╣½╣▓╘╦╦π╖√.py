str1="aa"
str2="bb"

list1=[1,2]
list2=[10,20]

t1=(1,2)
t2=(10,20)

dict1={"name":"Python"}
dict2={"num":100}


# +：合并（支持字符串、列表、元组）
print(str1+str2)
print(list1+list2)
print(t1+t2)
# print(dict1+dict2)  # 报错

# *：复制（支持字符串、列表、元组）
print(str1*5)
print(list1*5)
print(t1*5)
# print(dict1*5)  # 报错

# in 和 not in：判断是否存在和判断是否不存在（支持字符串、列表、元组、字典）
print("a" in str1)
print("b" not in str2)
print(1 in list1)
print(10 not in list2)
print(1 in t1)
print(10 not in t2)
print("name" in dict1)
print("num" not in dict2)
print("name" in dict1.keys())
print(100 not in dict2.values())