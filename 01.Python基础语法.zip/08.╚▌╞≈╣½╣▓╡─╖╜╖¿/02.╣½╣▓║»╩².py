# len()：计算容器中元素的个数

str1="abcdefg"
list1=[10,20,30,40,50]
t1=(10,20,30,40,50)
s1={10,20,30,40,50}
dict1={"name":"Python","num":100}
print(len(str1))
print(len(list1))
print(len(t1))
print(len(s1))
print(len(dict1))


# del或del()：删除

str2="abcdefg"
list2=[10,20,30,40,50]
t2=(10,20,30,40,50)
s2={10,20,30,40,50}
dict2={"name":"Python","num":100}
# del 后面跟容器名为删除容器
del(list2[0])
print(list2)
del dict2["name"]
print(dict2)


# max()和min()：返回容器中元素最大值和最小值

str3="abcdefg"
list3=[10,20,30,40,50]
print(max(str3))
print(min(str3))
print(max(list3))
print(min(list3))


# range(start,end,step)：生成start到end的数字，步长为step，供for循环使用

for i in range(1,10,1):
    print(i)

for j in range(1,10,2):
    print(j)

for k in range(10):
    print(k)
# range()生成的序列不包含end数字；步长和开始默认为1和0


# enumerate():函数用于将一个可遍历的数据对象（如列表、元组和字符串）组合为一个索引序列，同时列出数据和数据下标，一般用在for循环中

# 语法：enumerate(可遍历对象,start=num)（start默认等于0，可省略）
list5=['a','b','c','d','e']
for i in enumerate(list5):
    print(i)
for index,char in enumerate(list5,start=1):
    print(f"下标是{index}，对应的字母是{char}")