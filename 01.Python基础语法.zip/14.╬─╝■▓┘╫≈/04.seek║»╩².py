"""
作用：移动文件指针
语法：文件对象.seek(偏移量,起始位置)
起始位置：
        0：文件开头
        1；当前位置
        2：文件结尾
"""
f=open("test07.txt","r+")
f.seek(5,0)  # f.seek(5,1)报错
# 没有使用b模式选项打开的文件，只允许从文件头开始计算相对位置，从文件尾计算时就会引发异常
print(f.read())
f.close()

f=open("test07.txt","a+")
f.seek(5,0)
print(f.read())
f.seek(0)
print(f.read())
f.close()