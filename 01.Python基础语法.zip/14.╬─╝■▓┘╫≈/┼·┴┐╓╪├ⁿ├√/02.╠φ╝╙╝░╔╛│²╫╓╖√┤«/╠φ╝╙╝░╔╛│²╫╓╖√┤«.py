import os

# 构造条件的数据
flag=2

# 找到所有文件
file_list=os.listdir()

# 构造名字
for i in file_list:
    if flag==1:
        new_name="Python_"+i
    elif flag==2:
        num=len("Python_")
        new_name=i[num:]

# 重命名
    os.rename(i,new_name)