import os

# 找到所有文件
file_list=os.listdir()

# 构造名字
for i in file_list:
    new_name="Python_"+i

# 重命名
    os.rename(i,new_name)