# read()（文件对象.read(num)）如果没有传入num，读取整个文件
f=open("test04.txt","r")
# print(f.read())
print(f.read(10))
f.close()

# readlines() 按照行的模式把文件中的内容一次性读取，返回一个列表，每一行数据为一个元素
f=open("test05.txt","r")
print(f.readlines())
f.close

# readline() 一次性读取一行内容
f=open("test06.txt")
print(f"第一行：{f.readline()}")
print(f"第二行：{f.readline()}")
f.close