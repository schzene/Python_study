# 接收用户输入目标文件名
file_name=input("请输入您要备份的文件名：")

# 规划文件名
index=file_name.rfind(".")
if index>0:
    postfix=file_name[index:]
    file_backup=file_name[:index]+"[backup]"+postfix
else:
    print("错误！")

# 打开文件
f=open(file_name,"rb")
f_backup=open(file_backup,"wb")

# 备份文件写入
"""
while True:
    con=f.read(1)
    if len(con)==0:  # 读取完成
        break
    f_backup.write(con)
"""
f_backup.write(f.read())

# 关闭文件
f.close()
f_backup.close()