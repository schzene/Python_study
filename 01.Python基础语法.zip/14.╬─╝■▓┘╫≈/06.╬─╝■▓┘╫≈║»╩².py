"""
导入模块os
使用模块功能
"""
import os
"""
os.rename("test09.txt","test09.bin")  # 重命名文件
os.remove("test10.txt")  # 删除文件

os.mkdir("test00")  # 创建文件夹
os.mkdir("test01")
os.rmdir("test01")  # 删除文件夹
os.rename("test00","testoo")  # 重命名文件夹

print(os.getcwd())  # 获取当前目录
os.chdir("/mnt/e/source/Python/01.Python基础语法/14.文件操作/a")  # 改变默认目录（/mnt/e/source/Python/01.Python基础语法/14.文件操作/a）
os.mkdir("test00")
os.chdir("/mnt/e/source/Python/01.Python基础语法/14.文件操作")
print(os.listdir("a"))  # 获取目录列表（括号里为空表示为当前目录）
"""
