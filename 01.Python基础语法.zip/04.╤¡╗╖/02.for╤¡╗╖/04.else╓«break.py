# while...else...
i=1
while i<=7:
    if i==4:
        print('吃饱了不吃了') 
        break  
        # break终止了循环，使得else下面的代码不执行。
    print(f'吃第{i}个苹果')
    i+=1  
else :
    print('好像不执行我') 

# for...else... 
str1='abcdefg'
for i in str1 :
    if i=='d' :
        print(f'到{i}停止打印')
        break  # for...else...也一样
    print(i)
else :
    print('好像不执行我')    