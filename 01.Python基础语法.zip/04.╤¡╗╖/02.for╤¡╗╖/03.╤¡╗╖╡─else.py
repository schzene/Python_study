# while...else...
i=0
while i<9 :
    print('你电脑中毒了！')
    i+=1
else :  
# else把下面的代码与循环连接在一起了
# 循环不在了，下面的代码就不能执行
    print('呀，碰到杀毒软件了...')

# for...else...
str1='abcdefg'
for i in str1 :
    print(i)
else :
    print('end...')    