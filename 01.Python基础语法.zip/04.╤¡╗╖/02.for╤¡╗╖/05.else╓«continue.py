# while...else...
i=1
while i<=7 :    
    if i==4:
        print(f'第{i}个苹果有只虫子！扔了！')
        i+=1
        continue 
        # continue只跳过了一次循环，循环不终止。
    print(f'吃了第{i}个苹果')
    i+=1
else :
    print('任务未完成...')   

# for...else...
str1='abcdefg'
for i in str1 :
    if i=='d' :
        print('跳过c')
        continue  # for...else...也一样
    print(i)
else :
    print('好像会执行我')          