str1='abcdefg'
for i in str1 :
    if i=='c' :
        print('跳过c')
        continue
    if i=='f' :
        print('到f停止打印')
        break
    print(i)