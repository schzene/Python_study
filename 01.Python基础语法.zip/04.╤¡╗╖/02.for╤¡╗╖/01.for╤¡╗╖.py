'''
语法：
for 临时变量 in 序列 :
    重复执行的代码1
    重复执行的代码1
    ...
'''

str1='abcdefg'
for i in str1 :
    print(i)