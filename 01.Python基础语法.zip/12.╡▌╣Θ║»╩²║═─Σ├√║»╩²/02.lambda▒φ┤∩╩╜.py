# 如果函数有一个返回值，并且只有一句代码，可以使用lambda简化
# 语法：lambda 参数列表:表达式
# 注意：
#     1.lambda表达式的参数可有可无，函数的参数在lambda表达式中完全适用
#     2.lambda表达式能接收任何数量的参数，但只能返回一个表达式的值

def fn1():
    return 200
print(fn1)
print(fn1())

fn2=lambda:100
print(fn2)
print(fn2())

# 注意：直接打印lambda表达式，输出的是其内存地址
