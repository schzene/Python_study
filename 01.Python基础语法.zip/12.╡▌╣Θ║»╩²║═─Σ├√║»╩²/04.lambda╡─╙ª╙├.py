# 带判断的lambda
fn1=lambda a,b,:a if a>b else b
print(fn1(100,500))

# 列表数据按字典的key值排序
students=[
    {"name":"Bob","age":20},
    {"name":"Rose","age":19},
    {"name":"Jack","age":22}
]

# 按name值升值排序
students.sort(key=lambda x:x["name"])
print(students)

# 按name值降值排序
students.sort(key=lambda x:x["name"],reverse=True)
print(students)

# 按age值升值排序
students.sort(key=lambda x:x["age"])
print(students)