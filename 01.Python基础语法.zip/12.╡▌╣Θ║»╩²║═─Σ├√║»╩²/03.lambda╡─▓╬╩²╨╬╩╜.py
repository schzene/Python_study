# 无参数
fn1=lambda:100
print(fn1())

# 一个或多个参数
fn2=lambda a,b :a+b
print(fn2(10,20))

# 默认参数
fn3=lambda a,b,c=100:a+b+c
print(fn3(100,150))
print(fn3(100,150,200))

# 可变参数：*args
fn4=lambda *args:args
print(fn4(10,20,30))

# 可变参数：**kwargs
fn5=lambda **kwargs:kwargs
print(fn5(name="Python",num=100))