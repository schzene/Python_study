# num+num-1+...+2+1
def sum_num(num):
    # 1.如果是1，直接返回1——出口
    if num==1:
        return 1
    # 2.如果不是1，重复执行累加并返回结果
    else:
        return num+sum_num(num-1)

print(sum_num(100))
# 如果没有出口，报错：超出最大递归深度