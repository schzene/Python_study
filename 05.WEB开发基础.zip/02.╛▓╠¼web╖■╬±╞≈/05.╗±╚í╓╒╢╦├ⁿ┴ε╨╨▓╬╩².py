import sys

# 获取终端命令行参数
params = sys.argv

print(params, type(params))