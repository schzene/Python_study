import socket
import threading

def handle_client_request(new_socket):
    recv_data = new_socket.recv(4096)
    if len(recv_data) == 0:  # 判断接收的数据是否为0
        new_socket.close()
        return
    recv_content = recv_data.decode("utf-8")  # 对二进制数据进行解码
    print(recv_content)  # 对数据按照空格进行分割
    print(recv_content)  # 获取请求的资源路径
    request_list = recv_content.split(" ", maxsplit=2)
    request_path = request_list[1]
        
    # 判断请求的是否是根目录，如果是，则返回index.html
    if request_path == "/":
        request_path = "/index.html"

    try:
        # 提示：这里用rb模式，兼容打开图片文件
        with open("static" + request_path, "rb") as file:
            file_data = file.read()
    except Exception as e:
        # 代码执行到此，说明没有请求的文件，返回404状态信息
        with open("static/error.html", "rb") as error:
            error_data = error.read()
        response_line = "HTTP/1.1 404 Not Found\r\n"
        response_headr = "Server: PWS/1.0\r\n"
        response_body = error_data
        response = (
            response_line + 
            response_headr +
            "\r\n"
            ).encode("utf-8") + response_body
        new_socket.send(response)
                
    else:
        # 代码执行到此，说明文件存在，返回200状态信息
        response_line = "HTTP/1.1 200 OK\r\n"
        response_headr = "Server: PWS/1.0\r\n"
        response_body = file_data
        response = (
            response_line + 
            response_headr +
            "\r\n"
            ).encode("utf-8") + response_body
        new_socket.send(response)
    finally:
        new_socket.close()


def main():
    tcp_server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    tcp_server_socket.setsockopt(socket.SOL_SOCKET,socket.SO_REUSEADDR,True)
    tcp_server_socket.bind(("", 8000))
    tcp_server_socket.listen(128)
    while True:
        (new_socket, ip_port) = tcp_server_socket.accept()
        sub_thread = threading.Thread(target=handle_client_request,args=new_socket)
        sub_thread.setDaemon(True)
        sub_thread.start()

if __name__ == "__main__":
    main()