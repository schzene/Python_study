# 导入进程包
import multiprocessing

"""
Process进程类的说明
    Process([group [,target [,name [,args [, kwargs]]]]])
        group：指定进程组，目前只能使用None
        target：执行的目标程序名
        name：进程名字
        args：以元组方式给执行任务传参
        kwargs：以字典方式给执行任务传参
    Process创建的实例对象的常用方法：
        start()：启动子进程实例（创建子程序）
        join()：等待子程序执行结束
        terminate()：不管任务是否完成，立即终止子程序
    Process创建的实例对象的常用属性：
        name：当前进程的别名，默认为Process-N，N为从1开始递增的整数
"""
import time

def run():  # proc
    for i in range(3):
        print("process is running...")
        time.sleep(0.5)
def main_proc():  # 主进程
    for i in range(3):
        print("main process is running...")
        time.sleep(0.5)

def run1():  # run1
    for i in range(3):
        print("proc1 is running...")
        time.sleep(0.5)
def run2():  # run2
    for i in range(3):
        print("proc2 is running...")
        time.sleep(0.5)

if __name__=="__main__":
    # 创建子进程（自己手动创建的进程为子进程）
    proc=multiprocessing.Process(target=run)  # group目前只能用None，一般不需要设置
    proc1=multiprocessing.Process(target=run1)
    proc2=multiprocessing.Process(target=run2)

    # 启动进程执行对应的任务
    proc.start()

    # 主进程执行任务
    main_proc()

    time.sleep(1)
    proc1.start()
    proc2.start()

# 进程执行是无序的，具体哪个进程先执行是由操作系统调度决定的

# 注意：
"""
对于Linux和Mac主进程执行的代码不会进行复制，
但是对于Windows系统来说主进程执行的代码也会进行复制执行
对于Windows来说创建子进程的代码如果进行复制执行，
相当于递归无限制创建子进程，会报错
解决方法是通过判断是否是主模块来解决
"""