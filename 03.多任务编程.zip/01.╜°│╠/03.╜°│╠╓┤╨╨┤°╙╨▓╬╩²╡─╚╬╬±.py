import multiprocessing

def show_info(name,age):
    print(name,age)

if __name__=="__main__":
    # 创建子进程
    # 以元组形式传参，元组里面的元素要和函数里面的元素顺序保持一致
    # sub_process=multiprocessing.Process(target=show_info,args=("Python",20))

    # 以字典形式传参,字典里面的key要和函数里面的参数名保持一致，没有顺序要求
    sub_process=multiprocessing.Process(target=show_info,kwargs={"age":20,"name":"Python"})

    # 启动进程
    sub_process.start()