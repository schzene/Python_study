import multiprocessing
import time

# 1.进程之间不共享全局变量
g_list=list()  # 定义全局变量
def add_data():  # 添加数据的任务
    for i in range(3):
        # 因为列表是可变类型，可以在原有内存的基础上修改数据，并且修改后·内存地址不变
        # 所以不需要加上global关键字
        # 加上global表示要修改全局变量的内存地址
        g_list.append(i)
        print("add:",i)
        time.sleep(0.2)
    print("finished:",g_list)
def read_data():  # 读取数据的任务
    print("read:",g_list)

if __name__=="__main__":
    add_process=multiprocessing.Process(target=add_data)  # 添加数据的子进程
    read_process=multiprocessing.Process(target=read_data)  # 读取数据的子进程

    # 启动进程执行对应的任务
    add_process.start()
    add_process.join()  # 当前进程（主进程）等待添加数据的进程完成以后再继续往下执行
    read_process.start()
"""
创建子进程其实就是对主进程资源进行复制，
子进程其实就是主进程的一个副本
"""


# 2.主进程默认会等待所有的子进程执行结束再结束
"""
def task():
    for i in range(10):
        print("running...")
        time.sleep(0.2)
if __name__=="__main__":  # 标准Python写法
    sub_process=multiprocessing.Process(target=task)  # 创建子进程
    ## sub_process.daemon=True  # 把子进程设置成为守护主进程
    sub_process.start()

    time.sleep(0.5)  # 主进程延迟
    sub_process.terminate()  # 退出主进程之前，先让子进程进行销毁
    print("over")
"""
# 主进程退出子进程销毁的方法
"""
1.让子进程设置成为守护主进程，主进程退出子进程销毁，子进程会依赖主进程
2.让主进程退出之前先让子进程销毁
"""