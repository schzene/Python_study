# 获取进程编号的目的是验证主进程和子进程的关系，可以得知子进程是由哪个主进程创建出来的
"""
获取进程编号的两种操作
    获取当前进程编号
    获取当前父进程编号
"""
# os.getpid()表示获取当前1进程编号
import multiprocessing
import os
import time

def run1():
    proc1_id=os.getpid()
    print("proc1 id:",proc1_id,multiprocessing.current_process())
    parnet_id=os.getppid()
    print("proc1 parent id:",parnet_id)
    for i in range(3):
        print("proc1 is running...")
        time.sleep(0.5)
        # 扩展：根据进程编号kill指定进程，9代表强制kill
        os.kill(proc1_id,9)

def run2():
    proc2_id=os.getpid()
    print("proc2 id:",proc2_id,multiprocessing.current_process())
    parnet_id=os.getppid()
    print("proc2 parent id:",parnet_id)
    for i in range(3):
        print("proc2 is running...")
        time.sleep(0.5)

if __name__=="__main__":
    main_process_id=os.getpid()
    print("main process id:",main_process_id,multiprocessing.current_process())
    # 当前进程，主进程

    proc1=multiprocessing.Process(target=run1,name="named_process")
    print("proc1:",proc1)
    proc2=multiprocessing.Process(target=run2)
    print("proc2:",proc2)

    proc1.start()
    proc2.start()

