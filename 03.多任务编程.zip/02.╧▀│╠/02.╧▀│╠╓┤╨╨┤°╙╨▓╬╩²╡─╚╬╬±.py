import threading

def show_info(name,age):
    print(f"name: {name}, age: {age}")

if __name__=="__main__":
    # 创建子进程
    # 以元组方式传参，要保证元组里面元素的顺序和函数的参数一致
    # sub_thread=threading.Thread(target=show_info,args=("Python",30))

    # 以字典方式传参，要保证字典里面的key和函数的参数保持一致
    sub_thread=threading.Thread(target=show_info,kwargs={"age":30,"name":"Python"})

    # 启动线程执行对应任务
    sub_thread.start()