# 导入线程模块
import threading

"""
Thread进程类的说明
    Thread([group [,target [,name [,args [, kwargs]]]]])
        group：指定进程组，目前只能使用None
        target：执行的目标程序名
        args：以元组方式给执行任务传参
        kwargs：以字典方式给执行任务传参
        name：线程名，一般不用设置
"""
import time

def run1():  # run1
    c_thread=threading.current_thread()
    print("run1:",c_thread)
    for i in range(3):
        print("thread1 is running...")
        time.sleep(0.5)
def run2():  # run2
    c_thread=threading.current_thread()
    print("run2:",c_thread)
    for i in range(3):
        print("thread2 is running...")
        time.sleep(0.5)

if __name__=="__main__":
    c_thread=threading.current_thread()  # 获取当前进程
    print("main:",c_thread)

    thread_1=threading.Thread(target=run1,name="my_thread")  # 创建子线程
    thread_2=threading.Thread(target=run2)

    thread_1.start()  # 启动子线程执行相应任务
    thread_2.start()
