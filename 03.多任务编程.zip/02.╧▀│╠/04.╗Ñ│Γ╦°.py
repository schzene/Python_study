# 线程同步：保证同一时刻只有一个线程去操作全局变量
# 同步：就是协同步调，按预定的先后次序进行运行
"""
线程同步的方式：
    1.线程等待（join）
    2.互斥锁
"""
import threading

# 创建互斥锁，Lock本质上是一个函数，通过调用函数可以创建一个互斥锁
mutex=threading.Lock()

g_num=0  # 定义全局变量

def task4_1():  # 循环执行1000000执行的任务
    global g_num
    mutex.acquire()  # 上锁
    for i in range(1000000):
        g_num+=1
    print("task1 finished:",g_num)
    mutex.release()  # 释放锁

def task4_2():  # 循环执行1000000执行的任务
    global g_num
    mutex.acquire()  # 上锁
    for i in range(1000000):
        g_num+=1
    print("task2 finished:",g_num)
    mutex.release()  # 释放锁

if __name__=="__main__":
    # 创建两个子线程
    thread1=threading.Thread(target=task4_1)
    thread2=threading.Thread(target=task4_2)

    # 启动线程执行任务
    thread1.start()
    thread2.start()

# 互斥锁可以保证同一时刻只有一个线程去执行代码，能够保证全局变量的数据没有问题
# 线程等待和互斥锁都是把多任务改成单任务执行，保证了数据的准确性，但是执行性能会下降