import threading
import time
"""
# 1.线程之间执行是无序的，具体哪个线程执行是由CPU调度决定的
def task1():
    time.sleep(1)
    # 获取当前进程
    print(threading.current_thread())
if __name__=="__main__":
    # 循环创建大量进程，测试线程之间执行是否无序
    for i in range(20):
        # 每循环一次创建一个子线程
        sub_thread1=threading.Thread(target=task1)
        sub_thread1.start()


# 2.主线程会等待所有的子线程执行结束后再结束
def task2():
    while True:
        print("running...")
        time.sleep(0.2)
if __name__=="__main__":
    print("\nstart\n")
    # daemon=True表示创建的子线程守护主线程，主线程退出子线程直接销毁
    # sub_thread2=threading.Thread(target=task2,daemon=True)
    sub_thread2=threading.Thread(target=task2)
    sub_thread2.setDaemon(True)  # 把子线程设置成为守护主线程
    sub_thread2.start()
    time.sleep(1)  # 主线程延时执行1秒
    print("\nover\n")


# 3.线程之间共享全局变量
g_list=list()
def add_data():  # 添加数据的任务
    for i in range(3):
        print("add:",i)
        g_list.append(i)  # 每循环一次把数据添加到全局变量
        time.sleep(0.2)
    print("finished:",g_list)
def read_data():  # 读取数据的任务
    print(g_list)
if __name__=="__main__":
    add_thread=threading.Thread(target=add_data)  # 添加创建数据的子线程
    read_thread=threading.Thread(target=read_data)  # 添加读取数据的子线程

    # 启动线程
    add_thread.start()
    add_thread.join()  # 当前线程（主线程）等待添加数据的子线程执行完成以后代码再继续执行
    read_thread.start()
# 因为多线程在同一个进程里面，所以多线程可以共享全局变量
"""

# 4.线程之间共享全局变量数据可能出现错误问题
g_num=0  # 定义全局变量
def task4_1():  # 循环执行1000000执行的任务
    global g_num
    for i in range(1000000):
        g_num+=1
    print("task1 finished:",g_num)
def task4_2():  # 循环执行1000000执行的任务
    global g_num
    for i in range(1000000):
        g_num+=1
    print("task2 finished:",g_num)
if __name__=="__main__":
    # 创建两个子线程
    thread1=threading.Thread(target=task4_1)
    thread2=threading.Thread(target=task4_2)

    # 启动线程执行任务
    thread1.start()
    thread1.join()  # 解决方法：线程等待，让第一个线程先执行，然后再让第二个线程再执行，保证数据不会有问题
    thread2.start()