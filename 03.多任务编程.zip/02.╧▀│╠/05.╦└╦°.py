# 死锁：一直在等待对方释放锁的情景叫死锁
import threading
locks=threading.Lock()  # 创建互斥锁
def get_value(index):
    locks.acquire()  # 上锁
    my_list=[1,4,6]
    if index>=len(my_list):
        print("Error:",index)
        locks.release()  # 取值不成功也要释放互斥锁，不影响后面的线程
        # 锁需要在合适的地方进行释放，防止死锁
        return
    print(my_list[index])
    locks.release()  # 释放锁

if __name__=="__main__":
    for i in range(10):
        # 每循环一次创建一个子进程
        sub_thread=threading.Thread(target=get_value,args=(i,))
        # 启动线程执行任务
        sub_thread.start()