# 导入socket模块
import socket

if __name__=="__main__":
    # 创建TCP客户端套接字
    # 1.AF_INET:表示IPv4
    # 2.SOCK_SPREAM：TCP传输协议
    tcp_client_socket=socket.socket(socket.AF_INET,socket.SOCK_STREAM)
    # 和服务器应用程序建立连接
    ip_addr=input("Please input the IP address:")
    try:
        tcp_client_socket.connect((ip_addr,9090))  # 代码执行到此，说明连接建立成功
    except:
        print("connecting failed, exit.")
        exit()
    # 发送数据到服务端
    send_content=input()
    send_data=send_content.encode("utf-8")  # 对字符串进行编码成为二进制数据
    tcp_client_socket.send(send_data)
    # 接收服务端的数据
    recv_data=tcp_client_socket.recv(1024)
    recv_content=recv_data.decode("utf-8")
    print("receive the data:",recv_content)
    # 关闭套接字
    tcp_client_socket.close()


"""
创建客户端socket对象
socket.socket(AddressFamily,Type)
参数说明：
        AddressFamily表示IP地址类型，分别为IPv4和IPv6
        Type表示传输协议类型
方法说明：
        connect((host,port))表示和服务器套接字建立链接，host是服务器IP地址，port是应用程序的端口号
        send(data)表示发送数据，data是二进制数据
        recv(buffersize)表示接收数据，buffersize是每次接收数据的长度
"""
# 客户端程序不强制绑定端口号