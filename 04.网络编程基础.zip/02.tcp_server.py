# 导入socket模块
import socket

if __name__=="__main__":
    # 创建TCP服务端套接字
    tcp_server_socket=socket.socket(socket.AF_INET,socket.SOCK_STREAM)
    # 设置端口号复用，让程序退出端口号立即释放
    # tcp_server_socket
    # 绑定端口号
    tcp_server_socket.bind(("",9090))
    # 设置监听
    tcp_server_socket.listen(128)
    # 等待接受客户端的连接请求
    # 注意： listen后的套接字是被动套接字，只负责接收新的客户端的连接请求，不能收发消息
    #       每次当客户端和服务端建立连接成功都会返回一个新的套接字
    # tcp_server_socket只负责等待接收客户端的连接请求，收发消息不用该套接字
    (new_client,ip_port)=tcp_server_socket.accept()
    print("connected, the host is:",ip_port)
    # 接收客户端的数据
    # 收发消息都使用返回的新的套接字
    recv_data=new_client.recv(1024)
    recv_content=recv_data.decode("utf-8")
    print("receive a data:",recv_content)
    # 发送数据到客户端
    send_content=input()
    send_data=send_content.encode("utf-8")
    new_client.send(send_data)
    # 关闭服务端与客户端的套接字，表示和客户端终止通信，但是之前连接成功的其他客户端还能正常通信
    new_client.close()
    # 关闭套接字，表示服务端不再等待接收客户端的连接请求
    tcp_server_socket.close()


"""
方法说明：
        bind((host,port))表示绑定端口号，host是IP地址，port是端口号，
        IP地址一般不指定，表示本机的任何一个IP地址都可以
        listen(backlog)表示设置监听，backlog参数表示最大等待建立连接的个数
        accept()表示等待接受客户端的连接请求
        send(data)表示发送数据，data是二进制数据
        recv(buffersize)表示接收数据，buffersize是每次接收数据的长度
"""
# 当客户端的套接字用close后，服务端的recv会解阻塞，返回的数据长度为0，服务端可以通过返回数据的长度来判断客户端是否下线，
# 反之服务端关闭套接字，客户端的recv也会解阻塞，返回的数据长度也为0