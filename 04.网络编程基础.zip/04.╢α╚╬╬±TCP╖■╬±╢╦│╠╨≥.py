import socket
import threading

# 处理客户端请求的任务
def handle_client_request(new_client,ip_port):
    print("connected, the host is:",ip_port)
    while True:
        recv_data=new_client.recv(1024)
        if recv_data:
            recv_content=recv_data.decode("utf-8")
            print("receive a data:",recv_content)
            send_content="received."
            send_data=send_content.encode("utf-8")
            new_client.send(send_data)
        else:   # 客户端关闭链接
            print(f"client {ip_port} offline")
            break
    new_client.close()

if __name__=="__main__":
    tcp_server_socket=socket.socket(socket.AF_INET,socket.SOCK_STREAM)
    tcp_server_socket.setsockopt(socket.SOL_SOCKET,socket.SO_REUSEADDR,True)
    tcp_server_socket.bind(("",9090))
    tcp_server_socket.listen(128)
    while True:  # 循环等待客户端的连接请求
        (new_client,ip_port)=tcp_server_socket.accept()
        # 当客户端和服务端建立连接成功时，创建子线程，让子线程专门负责接收客户端的消息
        sub_thread=threading.Thread(target=handle_client_request,args=(new_client,ip_port))
        sub_thread.setDaemon(True)
        sub_thread.start()
    # tcp_server_socket.close()
    # 因为服务端的程序要一直运行，故此代码可省略。
