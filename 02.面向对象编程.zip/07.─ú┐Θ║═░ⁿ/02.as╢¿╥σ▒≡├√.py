# import 模块名 as 别名（模块别名）
import time as tt
tt.sleep(2)
# time.sleep(2)  # 报错
print("hello")

# from 模块名 import 功能名 as 别名（功能别名）
from time import sleep as sl
sl(2)
# sleep(2)  # 报错
print("hello")
