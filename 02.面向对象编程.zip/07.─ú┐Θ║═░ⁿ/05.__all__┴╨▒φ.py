from my_module2 import *
testA()

# all列表里面没有testB
# testB()  # 报错