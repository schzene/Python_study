# Python模块（module），是一个Python文件，以.py结尾，包含了Python对象定义和Python语句。
# 模块能定义函数、类和变量，模块里也能包含可执行的代码。


# import 模块名

# 1.导入模块
# import 模块名
# import 模块名1, 模块名2...

# 2.调用功能
# 模块名.功能名

import math
print(math.sqrt(9))
print()


# from 模块名 import 功能名1, 功能2, ...

from math import sqrt
print(sqrt(9))
print()
# 不需要写模块名


# from 模块名 import *

from math import *
print(sqrt(9))
# 调用全部功能
