# 调用模块
import my_module1
my_module1.testA(1, 2)