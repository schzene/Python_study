# 使用from xxx import * 导入时，只能导入这个列表中的元素
__all__=["testA"]

def testA():
    print("testA")

def testB():
    print("testB")