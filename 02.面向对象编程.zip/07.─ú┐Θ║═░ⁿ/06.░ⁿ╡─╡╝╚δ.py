"""
包将所有联系的模块组织在一起，即放到同一文件夹下，
并且在这个文件夹下创建一个名字为__init__.py文件，
那么这个文件夹就称之为包
__init__.py控制包的导入行为
"""

# 方法1
"""
import my_packge.my_module3
my_packge.my_module3.info_print3()
"""

# 方法2
# 注意：必须在__init__.py文件中添加__all__ = []，控制允许导入的模块列表
"""
from my_packge import *
# my_module3.info_print3()  # 报错
my_module4.info_print4()
"""
