print(3)

def info_print3():
    print("my_module3")