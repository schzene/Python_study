print(4)

def info_print4():
    print("my_module4")