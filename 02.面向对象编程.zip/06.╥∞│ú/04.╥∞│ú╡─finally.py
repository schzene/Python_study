try:
    f=open("test.txt",'r')
except Exception as result:
    print(result)
else:
    print("No Error")
finally:  # 无论是否异常都要执行的代码
    print("EXIT")