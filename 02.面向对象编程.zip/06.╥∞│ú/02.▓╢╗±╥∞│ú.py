try:
    print(1/0)
except ZeroDivisionError:
    print("Error")

"""
try:
    f=open("test.txt",'r')
except NameError:
    print("Error")
"""

# 如果尝试执行的代码的异常类型和要捕获的异常类型不一样，则无法捕获异常
# 一般try下方只放一行尝试执行的代码

# 捕获多个指定异常
try:
    print(1/0)
except (NameError,ZeroDivisionError):
    print("Error")

# 捕获异常描述信息
try:
    print(1/0)
except (NameError,ZeroDivisionError) as result:
    print(result)

# 捕获所有异常
try:
    f=open("test.txt",'r')
except Exception as result:
    print(result)