try:
    f=open("test.txt",'r')
except:
    print("Error")