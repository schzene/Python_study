try:
    print(1)
except Exception as result:
    print(result)
else:  # 表示没有错误时执行的代码
    print("No Error")