import time
try:
    f = open("test.txt")  # 只读模式
    try:
        while True:
            content = f.readline()
            if len(content) == 0:
                break
            time.sleep(2)
            print(content)
    except:
        # 如果在读取文件中产生异常，就会捕捉到(eg：ctrl+c)
        print("Terminate Unexpectedly.")
    finally:
        f.close()
        print("Close the File")
except:
    print("File Not Found")
