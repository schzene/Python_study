# -*-coding:utf-8-*-
"""
系统需求：
        学员数据存储在文件中
系统功能：
        添加、删除、修改、查询学员信息
        显示所有学员信息
        保存学员信息
        退出系统
"""
# 角色分析：学员、管理系统
# 注意：
#     1.为了方便维护代码，一般一个角色一个程序文件
#     2.项目要有主程序入口，习惯为main.py

# 1.导入manager_system模块
from manager_system import *

# 2.启动学员管理系统
if __name__=="__main__":
        student_manager=StudentManager()
        student_manager.run()