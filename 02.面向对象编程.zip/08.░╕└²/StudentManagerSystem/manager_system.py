"""
存储数据的形式：文件（student.data）
    加载文件数据
    修改数据后保存到文件
存储数据的形式：列表存储学员对象
"""

# 导入student模块，添加学员函数内部需要创建的学员对象
from student import *

class StudentManager(object):
    def __init__(self):
        # 存储数据所用的列表
        self.student_list=[]

    # 1.程序入口函数，启动程序后执行的函数
    def run(self):
        self.load_student()  # 加载学员信息
        while True:
            self.show_menu()  # 显示功能菜单
            menu_num=input("请输入功能序号：")  # 用户输入功能序号

            if menu_num=="1":  # 根据功能序号执行不同的功能
                self.add_student()  # 添加学员
            elif menu_num=="2":
                self.del_student()  # 删除学员
            elif menu_num=="3":
                self.modify_student()  # 修改学员信息
            elif menu_num=="4":
                self.search_student()  # 查询学员信息
            elif menu_num=="5":
                self.show_student()  # 显示所有学员信息
            elif menu_num=="6":
                self.save_student()  # 保存学员信息
            elif menu_num=="7":
                break  # 退出系统
            else:
                print("指令输入错误，请重新输入！")
    
    # 2.系统功能函数
    def load_student(self):
        """加载学员信息"""
        # 尝试以"r"模式打开文件，文件不存在则提示用户；文件存在则读取数据
        try:
            file=open("student.data","r")
        except:
            try:
                file=open("student.data","w")
                file.write("[]")
                file.close()
            except:
                print("文件加载失败")
        else:
            # 读取数据
            data=file.read()
            data_list=eval(data)
            self.student_list=[Student(i["name"],i["gender"],i["tel"]) for i in data_list]
            file.close()

    def show_menu(self):
        """显示功能菜单"""
        print("-"*20)
        print("请选择功能：")
        print("1：添加学员")
        print("2：删除学员")
        print("3：修改学员信息")
        print("4：查询学员信息")
        print("5：显示所有学员信息")
        print("6：保存学员信息")
        print("7：退出系统")
        print("-"*20)

    def add_student(self):
        """添加学员"""
        # 用户输入信息
        name=input("请输入您的姓名:")
        gender=input("请输入您的性别：")
        tel=input("请输入您的手机号:")

        # 创建学员对象
        stu=Student(name,gender,tel)
        
        # 将数据传入到学员列表
        self.student_list.append(stu)

        print(f"{stu} 添加成功！")

    def del_student(self):
        """删除学员"""
        # 用户输入目标学员姓名
        del_name=input("请输入要删除的学员姓名：")

        # 如果学员存在则删除数据，否则提示学员不存在
        for i in self.student_list:
            if i.name==del_name:
                self.student_list.remove(i)
                print("删除成功！")
                break
        else:
            print("查无此人！")

    def modify_student(self):
        """修改学员信息"""
        # 用户输入目标学员姓名
        modify_name=input("请输入要修改学员的姓名：")

        # 如果学员存在则修改数据，否则提示学员不存在
        for i in self.student_list:
            if i.name==modify_name:
                i.name=input("新姓名：")
                i.gender=input("新性别：")
                i.tel=input("新手机号：")
                print(f"修改成功！新的学员信息为：{i}")
                break
        else:
            print("查无此人！")

    def search_student(self):
        """查询学员信息"""
        # 用户输入目标学员姓名
        search_name=input("请输入要查询学员的姓名：")

        # 如果学员存在则查询数据，否则提示学员不存在
        for i in self.student_list:
            if i.name==search_name:
                print(f"学员信息为：{i}")
                break
        else:
            print("查无此人！")

    def show_student(self):
        """显示所有学员信息"""
        print("姓名\t性别\t手机号")
        for i in self.student_list:
            print(f"{i.name}\t{i.gender}\t{i.tel}")

    def save_student(self):
        """保存学员信息"""
        # 打开文件
        try:
            file=open("student.data","w")
        except:
            print("文件加载失败")
        else:
            # 文件写入学员数据
            # 注意：文件写入的数据不是学员对象的内存地址，要把学员数据转化为列表字典数据再做存储
            data_list=[i.__dict__ for i in self.student_list]
            # 注意：文件内数据要求为字符串类型，故先要转换数据类型为字符串才能向文件写入数据
            file.write(str(data_list))

            # 关闭文件
            file.close
        