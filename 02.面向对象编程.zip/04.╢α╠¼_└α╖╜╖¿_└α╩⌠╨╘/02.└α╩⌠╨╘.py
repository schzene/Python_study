# 类属性就是类对象所拥有的属性，它被该类的所有实例对象所共有
# 类属性可以使用类对象或实例对象访问

class Dog(object):
    tooth=10

dog1=Dog()
dog2=Dog()

print(Dog.tooth)
print(dog1.tooth)
print(dog2.tooth)

"""
优点：
    1.记录的某项数据始终保持一致时，则定义类属性。
    2.实例属性要求每个对象为其单独开辟一份内存空间来记录数据，
      而类属性为全类所共有，仅占用一份内存，更加节省内存空间
"""

# 修改类属性
Dog.tooth=12
print(Dog.tooth)
print(dog1.tooth)
print(dog2.tooth)

# 不能通过对象修改属性，否则是创建了一个实例属性
dog1.tooth=20

print(Dog.tooth)
print(dog1.tooth)
print(dog2.tooth)
