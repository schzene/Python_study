"""
多态：一类事物有多种形态（一个抽象类有多个子类，因而多态的概念依赖于继承）
定义：一种使用对象的方式，子类重写父类方法，调用不同子类对象的相同父类方法，可以产生不同的执行结果
好处：调用灵活，更容易编写出通用的代码，做出通用的编程，以适应需求的不断变化
"""

class Dog(object):
    def work(self):  # 父类提供统一的方法
        print("指哪打哪...")

class ArmyDog(Dog):  # 继承Dog类
    def work(self):  # 子类重写父类方法
        print("追击敌人...")

class DrugDog(Dog):
    def work(self):
        print("追查毒品...")
    
class Person(object):
    def work_with_dog(self,dog):  # 传入不同对象，执行不同代码
        dog.work()

army=ArmyDog()
drug=DrugDog()

P1=Person()
P1.work_with_dog(army)
P1.work_with_dog(drug)