# 需求涉及两个事物：房子和家具，故案例涉及两个类：房子类和家具类
class House():
    def __init__(self,address,area):
        self.address=address  # 地理位置
        self.area=area  # 房屋面积
        self.free_area=area  # 剩余面积
        self.furniture=[]  # 家具列表

    def add_furniture(self,item):
        """容纳家具"""
        if self.free_area>=item.area:
            self.furniture.append(item.name)
            self.free_area-=item.area
        else:
            print("家具太大，剩余面积不足，无法容纳")

    def __str__(self):
        return f"房子坐落于{self.address}，占地面积为{self.area}，剩余面积为{self.free_area}，家具有{self.furniture}"

class Furniture():
    def __init__(self,name,area):
        self.name=name  # 家具名字
        self.area=area  # 家具列表

House1=House("北京",100)
print(House1)

Bed=Furniture("床",10)
House1.add_furniture(Bed)
print(House1)

Sofa=Furniture("沙发",6)
House1.add_furniture(Sofa)
print(House1)

Pool=Furniture("泳池",90)
House1.add_furniture(Pool)
print(House1)