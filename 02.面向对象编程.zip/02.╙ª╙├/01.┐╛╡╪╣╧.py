"""
1.被烤的时间和对应地瓜状态
    0-3分钟：生的
    3-5分钟：半生不熟
    5-8分钟：熟的
    8分钟以上：烤糊了
2.添加的调料
    用户按自己的意愿添加调料
"""

# 分析：
# 需求涉及一个事物：地瓜，故案例涉及一个类：地瓜类

class SweetPotato():
    def __init__(self):
        self.cook_time=0  # 被烤的时间
        self.cook_static="生的"  # 地瓜的状态
        self.condiments=[]  # 调料列表

    def cook(self,time):  
        """定义烤地瓜方法"""
        self.cook_time+=time
        if 0<=self.cook_time<3:
            self.cook_static="生的"
        elif 3<=self.cook_time<5:
            self.cook_static="半生不熟"
        elif 5<=self.cook_time<8:
            self.cook_static="熟的"
        elif self.cook_time>=8:
            self.cook_static="烤糊了"

    def add_condiments(self,condiments):
        """添加调料"""
        self.condiments.append(condiments)

    def __str__(self):
        return f"这个地瓜被烤过的时间是{self.cook_time}，状态是{self.cook_static},添加了{self.condiments}"

SweetPotato1=SweetPotato()

SweetPotato1.cook(2)
SweetPotato1.add_condiments("酱油")
print(SweetPotato1)

SweetPotato1.cook(2)
SweetPotato1.add_condiments("辣椒酱")
print(SweetPotato1)

SweetPotato1.cook(2)
print(SweetPotato1)

SweetPotato1.cook(3)
print(SweetPotato1)