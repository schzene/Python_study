# 使用print输出对象的时候，默认打印对象的内存地址。
# 如果类定义了__str__()，那么就会打印__str__()中return的数据

class Washer():
    def __init__(self,width,height):
        self.width=width
        self.height=height
    
    def __str__(self):
        return "Introduction of the washer"

Washer1=Washer(400,500)
print(Washer1)  # Introduction of the washer