# 当删除对象时，Python解释器也会默认调用__del__()方法。
class Washer():
    def __init__(self,width,height):
        self.width=width
        self.height=height

    def __del__(self):
        print(f"{self}对象已被删除")

Washer1=Washer(400,500)
del Washer1