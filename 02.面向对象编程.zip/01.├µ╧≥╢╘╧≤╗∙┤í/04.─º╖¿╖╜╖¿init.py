# 在Python中，__xx__()的函数叫做魔法方法，指的是具有特殊功能的函数


# __init__()作用：初始化对象
class Washer():
    def __init__(self):  # 定义__init__，添加实例属性
        self.width=500
        self.height=800

    def print_info(self):
        print(f"The width of Washer is {self.width}")
        print(f"The height of Washer is {self.height}")

Washer1=Washer()
Washer1.print_info()
print("-"*29)
"""
注意：
    __init__()方法，在创建一个对象时默认被调用，不需要手动调用
    __init__(self)中的self参数，不需要开发者传递，Python解释器会自动把当前的对象引用传递过去
"""

# 带参数的__init__()
class Washers():
    def __init__(self,width,height):
        self.width=width
        self.height=height

    def print_info(self):
        print(f"The width of Washers is {self.width}")
        print(f"The height of Washers is {self.height}")

Washers1=Washers(400,500)
Washers1.print_info()
print("-"*29)
Washers2=Washers(500,800)
Washers2.print_info()
