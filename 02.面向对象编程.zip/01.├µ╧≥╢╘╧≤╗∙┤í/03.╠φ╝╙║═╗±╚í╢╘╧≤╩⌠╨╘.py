class Washer1():
    def wash(self):
        print("Washing...")
        print("Finished")

W1=Washer1()

# 类外面添加对象属性
#     语法：对象名.属性名=值 
W1.width=400
W1.height=500

# 类外面获取对象属性
#     语法：对象名.属性名
print(f"The width of Washer1 is {W1.width}")
print(f"The height of Washer1 is {W1.height}")

# 类里面获取对象属性
#     语法：self.属性名
class Washer2():
    def print_info(self):
        # 类里面获取实例属性
        print(f"The width of Washer2 is {self.width}")
        print(f"The height of Washer2 is {self.height}")
W2=Washer2()
W2.width=500
W2.height=800
W2.print_info()