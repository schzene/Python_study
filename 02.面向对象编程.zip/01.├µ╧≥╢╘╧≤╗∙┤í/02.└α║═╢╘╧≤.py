# 在面向对象编程过程中，有两个重要组成部分：类和对象
# 类和对象的关系：用类去创建一个对象
# 类是对一系列具有相同特征和行为的事物的统称，是一个抽象的概念
# 特征即是属性；行为即是方法
# 对象是类创建出来的真实事物（先有类，再有对象）

class Washer():  # 定义类（类名遵循大驼峰命名规则）
    def wash(self):  # self指的是调用该函数的对象
        print("Washing...")
        print("Finished")
        print(self)

Washer1=Washer()  # 创建对象（对象名=类名()）
print(Washer1)  # 验证成果 
Washer1.wash()  # 使用wash功能

print()

Washer2=Washer()  # 一个类创建多个对象
print(Washer2)
Washer2.wash()