class Master(object):
    def __init__(self):
        self.kongfu="[古法配方]"
    
    def make(self):
        print(f"运用{self.kongfu}制作")

class School(object):
    def __init__(self):
        self.kongfu="[新配方]"

    def make(self):
        print(f"运用{self.kongfu}制作")

class Prentice(School,Master):
    def __init__(self):
        self.kongfu="[独创配方]"

    def make(self):
        self.__init__()
        print(f"运用{self.kongfu}制作")

    def Master_make(self):
        Master.__init__(self)
        Master.make(self)

    def School_make(self):
        School.__init__(self)
        School.make(self)

class PrenticePlus(Prentice):
    pass

P2=PrenticePlus()
P2.make()
P2.Master_make()
P2.School_make()