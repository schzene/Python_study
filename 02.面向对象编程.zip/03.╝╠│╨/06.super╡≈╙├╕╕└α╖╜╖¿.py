class Master(object):
    def __init__(self):
        self.kongfu="[古法配方]"
    
    def make(self):
        print(f"运用{self.kongfu}制作")

class School(Master):
    def __init__(self):
        self.kongfu="[新配方]"

    def make(self):
        print(f"运用{self.kongfu}制作")

        # 2.1 super()带参数写法
        # super(School,self).__init__()
        # super(School,self).make()
        # 2.2 无参数super()
        super().__init__()
        super().make() 

class Prentice(School):
    def __init__(self):
        self.kongfu="[独创配方]"

    def make(self):
        self.__init__()
        print(f"运用{self.kongfu}制作")

    def make_all(self):
        # 方法一
        #       如果定义类名修改，这里也需要修改
        #       代码量太庞大，冗余
        # School.__init__(self)
        # School.make(self)
        # Master.__init__(self)
        # Master.make(self)

        # 方法二：super()
        # 2.1 super(当前类名,self).函数()
        # super(Prentice,self).__init__()
        # super(Prentice,self).make()
        # 2.2 无参数super()
        super().__init__()
        super().make()


P1=Prentice()

P1.make_all()
