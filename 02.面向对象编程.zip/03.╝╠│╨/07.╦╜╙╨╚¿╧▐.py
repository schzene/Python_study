class Master(object):
    def __init__(self):
        self.kongfu="[古法配方]"
    
    def make(self):
        print(f"运用{self.kongfu}制作")

class School(object):
    def __init__(self):
        self.kongfu="[新配方]"

    def make(self):
        print(f"运用{self.kongfu}制作")

class Prentice(School,Master):
    def __init__(self):
        self.kongfu="[独创配方]"
        self.__money=1000000  # 定义私有属性

# 在Python中，一般定义函数名get_xx获取私有属性，定义set_xx用来修改私有属性
    def get_money(self):  # 获取私有属性
        return self.__money

    def set_money(self):
        self.__money=1000001

    def __print_info(self):  # 定义私有方法
        print(self.kongfu)
        print(self.__money)

    def make(self):
        self.__init__()
        print(f"运用{self.kongfu}制作")

    def Master_make(self):
        Master.__init__(self)
        Master.make(self)

    def School_make(self):
        School.__init__(self)
        School.make(self)

class PrenticePlus(Prentice):
    pass

P1=Prentice()
P2=PrenticePlus()
# print(P2.__money)
# P2.__print.info()
# 私有属性和私有方法无法继承

print(P2.get_money())
P2.set_money()
print(P2.get_money())