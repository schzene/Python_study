class Master(object):
    def __init__(self):
        self.kongfu="[古法配方]"
    
    def make(self):
        print(f"运用{self.kongfu}制作")

class Prentice(Master):
    pass

P1=Prentice()
print(P1.kongfu)