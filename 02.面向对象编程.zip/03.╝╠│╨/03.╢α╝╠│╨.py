# 一个类继承多个父类

class Master(object):
    def __init__(self):
        self.kongfu="[古法配方]"
    
    def make(self):
        print(f"运用{self.kongfu}制作")

class School(object):
    def __init__(self):
        self.kongfu="[新配方]"

    def make(self):
        print(f"运用{self.kongfu}制作")

class Prentice1(Master,School):
    pass


P1=Prentice1()
print(P1.kongfu)
P1.make()
# 当一个类有多个父类的时候，默认使用第一个父类的同名属性和方法


# 子类重写父类同名属性和方法
class Prentice2(School,Master):
    def __init__(self):
        self.kongfu="[独创配方]"

    def make(self):
        print(f"运用{self.kongfu}制作")
        

P2=Prentice2()
print(P2.kongfu)
P2.make()
# 如果子类和父类拥有同名属性和方法，子类创建对象调用属性和方法的时候，调用到的是子类里面的同名属性和方法


print(Prentice2.__mro__)
# 查看其父类继承关系，用__mro__