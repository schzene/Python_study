class Master(object):
    def __init__(self):
        self.kongfu="[古法配方]"
    
    def make(self):
        print(f"运用{self.kongfu}制作")

class School(object):
    def __init__(self):
        self.kongfu="[新配方]"

    def make(self):
        print(f"运用{self.kongfu}制作")

class Prentice(School,Master):
    def __init__(self):
        self.kongfu="[独创配方]"

    def make(self):
        # 如果先调用父类属性和方法，父类属性会覆盖子类属性
        # 故在调用属性前，先调用自己子类的初始化
        self.__init__()
        print(f"运用{self.kongfu}制作")

    # 子类调用父类同名方法和属性：把父类的同名方法和属性再次封装
    # 调用父类方法，为保证用到的也是父类的属性，必须在调用方法前调用父类的初始化
    def Master_make(self):
        Master.__init__(self)
        Master.make(self)

    def School_make(self):
        School.__init__(self)
        School.make(self)

P1=Prentice()
P1.make()
P1.Master_make()
P1.School_make()
