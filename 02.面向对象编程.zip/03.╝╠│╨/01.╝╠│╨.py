# Python面向对象的继承指的是多个类之间的所属关系，即子类默认继承父类的所有属性和方法

# 父类A
class A(object):
    def __init__(self):
        self.num=1

    def print_info(self):
        print(self.num)

# 子类B
class B(A):
    pass

test=B()
test.print_info()

# 在Python中，所有类默认继承object类，object类是顶级类或基类；其他子类叫派生类
